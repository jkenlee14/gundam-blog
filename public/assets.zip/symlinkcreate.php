<?php 
symlink('/storage/app/public', '/public_html/storage'); ?>